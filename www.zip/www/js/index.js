var links = [];
var pages = [];
var numLinks = 0;
var numPages = 0;
var counter = 0;
var totalContacts = 0;

window.addEventListener('DOMContentLoaded', function() {
    app.initialize();
});

var app = {
    initialize: function() {
        this.bindEvents();
        //app.appStart();
    },
    bindEvents: function() {
        document.addEventListener('deviceready', app.onDeviceReady, false);
        
        // TODO: Bind "online" event listener
        
        // TODO: Bind "offline" event listener
    },
    onDeviceReady: function() {
        // Add controls such as link clicks to the app
        app.addControls();
        
        // Check if it's the first time the user runs the app
        var firstRun = localStorage.getItem("key");
        if (firstRun == null) {
            // Initialize all contacts from Simon's JSON file to the device contacts
            app.initializeContacts();
        } else {
            // Get all contacts from the device contacts and display it on the home page
            app.getContacts();
        }
    },
    addControls: function() {
        links = document.querySelectorAll("[data-role='link']");
        pages = document.querySelectorAll("[data-role='page']");
        numLinks = links.length;
        numPages = pages.length;
        
        for (var l=0; l<numLinks; l++) {
            links[l].addEventListener('click', this.handleClick, false);
        }
        
        var addBtn = document.getElementById("addContactBtn");
        addBtn.addEventListener('click', this.getGeoInfo, false);

        var addBtn = document.getElementById("doneBtn");
        addBtn.addEventListener('click', this.addContact, false);
        
    },
    handleClick: function(link) {
        link.preventDefault();
        var href = link.currentTarget.href;
        var parts = href.split("#");
        app.loadPage(parts[1]);
    },
    loadPage: function(page) {
        for (var p=0; p<numPages; p++) {
            if (pages[p].id == page) {
                pages[p].className = "active";
            } else {
                pages[p].className = "";
            }
        }
    },
    initializeContacts: function() {
        var request = new XMLHttpRequest();
		request.open("GET", "https://dl.dropboxusercontent.com/u/887989/MAD9135/contacts.json", true);
		request.onreadystatechange = function() {
			if (request.readyState == 4) {
				if (request.status == 200 || request.status == 0) {
					var result = JSON.parse(request.responseText);
                    totalContacts = result.length;
                    
                    // Assign all contacts to the device contacts
                    // Declare the contact variables so we just have to make the variables once
                    var newContact;
                    var contactName;
                    var contactAddresses = [];
                    var contactPhoneNumbers = [];
                    var contactEmails = [];
                    for (var i=0; i<result.length; i++) {
                        // Create the contact
                        newContact = navigator.contacts.create();
                        newContact.displayName = result[i].firstname + " " + result[i].lastname;
                        
                        // Assign the contact's name
                        contactName = new ContactName();
                        contactName.givenName = result[i].firstname;
                        contactName.familyName = result[i].lastname;
                        newContact.name = contactName;
                        
                        // Assign the contact's addresses
                        contactAddresses[0] = new ContactAddress();
                        contactAddresses[0].pref = true;
                        contactAddresses[0].type = "home";
                        contactAddresses[0].formatted = result[i].street + ", " + result[i].city + ", " + result[i].state;
                        contactAddresses[0].streetAddress = result[i].street;
                        contactAddresses[0].locality = result[i].city;
                        contactAddresses[0].country = result[i].state;
                        newContact.addresses = contactAddresses;
                        
                        // Assign the contact's phone numbers
                        contactPhoneNumbers[0] = new ContactField("mobile", result[i].phone, true);
                        newContact.phoneNumbers = contactPhoneNumbers;
                        
                        // Assign the contact's emails
                        contactEmails[0] = new ContactField("home", result[i].email, true);
                        newContact.emails = contactEmails;
                        
                        // Save the contact
                        newContact.save(app.onContactSuccess, app.onContactError);
                    }
 				}
			}
		};
		request.send();
    },
    onContactSuccess: function(contact) {
        counter++;
        
        if (counter == totalContacts) {
            app.getContacts();
            localStorage.setItem("key", "1");
        }
    },
    onContactError: function(error) {
        counter++;
        
        if (counter == totalContacts) {
            app.getContacts();
            localStorage.setItem("key", "1");
        }
    },
    getContacts: function() {
        var fields = ["displayName"];
        var options = new ContactFindOptions();
        options.multiple = true;
        navigator.contacts.find(fields, app.onSuccess, app.onError, options);
    },
    onSuccess: function(contacts) {
        console.log("Successfully got " + contacts.length + " contacts!");
        var contactsWrapper = document.querySelector(".contacts");
        var contactList;
        var contactLink;
        for (var i=0; i<contacts.length; i++) {
            contactList = document.createElement("li");
            contactLink = document.createElement("a");
            contactLink.className = "contact";
            contactLink.innerHTML = contacts[i].displayName;
            contactList.appendChild(contactLink);
            contactsWrapper.appendChild(contactList);
        }
    },
    onError: function(contactError) {
        alert("Error with error code: " + contactError.code);
    },
    
    getGeoInfo: function()
    {
        navigator.geolocation.getCurrentPosition(app.onGeoSuccess, app.onGeoError);
    },
    
    onGeoSuccess: function(position)
    {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        var request = XMLHttpRequest();
        request.open("GET", 
            "http://open.mapquestapi.com/geocoding/v1/reverse?" + 
                     "key=Fmjtd|luur2hurn0%2Cbg%3Do5-9wasly&location=" + latitude + "," + longitude, true);
    
            request.onreadystatechange = function() 
                {
                    if (request.readyState == 4) 
                    {
                            if (request.status == 200 || request.status == 0) 
                            {
                                var currentLocation = JSON.parse(request.responseText);
                                //console.log("CurrentLocation" + currentLocation.results[0].locations[0].adminArea5);
                                var geoStreet = currentLocation.results[0].locations[0].street;
                                var streetAddressPopulate = document.getElementById("addressnew");
                                streetAddressPopulate.value = geoStreet;
                                var geoCity = currentLocation.results[0].locations[0].adminArea5;
                                var cityPopulate = document.getElementById("lastname");
                                cityPopulate.value = geoCity;
                                var geoPostalCode = currentLocation.results[0].locations[0].postalCode;
                                var geoPostalCodePopulate = document.getElementById("phone");
                                geoPostalCodePopulate.value = geoPostalCode;
                            }
                    }
                
            
    };
                request.send();
    
    },   
    
    addContact: function() 
    {
        var firstNameToAdd = document.getElementById("firstname").value; //firstName Input
        var lastNameToAdd = document.getElementById("lastname").value; //LastName Input
        var phoneToAdd = document.getElementById("phone").value; //phone Input
        var emailToAdd = document.getElementById("emailnew").value; //Not Working
        var addressToAdd = document.getElementById("addressnew").value; //Not Working
        
        //Add Name Fields To Contacts
        var contact = navigator.contacts.create();
        var name = new ContactName();    
        name.givenName = firstNameToAdd;
        name.familyName = lastNameToAdd;
        contact.name = name;
        
        //Add Address to Contacts under Formatted Option
        var address = []
        address[0] = new ContactAddress(true,"home","1 adress ofaddress",addressToAdd,"locality","Region","1111","Canada");
        contact.addresses = address; 
        
        //Add Phone Number Input To Contact
        var phoneNumbers = [];
        phoneNumbers[0] = new ContactField('mobile', phoneToAdd, false);
        contact.phoneNumbers = phoneNumbers;
        
        
            if ((firstNameToAdd == "") || (lastNameToAdd == "") || (phoneToAdd == ""))
            {
                alert("Required fields are missing!");
            }
            else
            {
                contact.save(app.onSaveSuccess,app.onSaveError); // To save, have to call save method on the object so its added to the contact db
            }
    
    },
   
    onSaveSucces: function(contact)
    {
        alert("Save Success");
    },

    // onSaveError: Failed to save the contact
    onSaveError: function(contactError) 
    {
        alert("Error = " + contactError.code);
    },

 };
